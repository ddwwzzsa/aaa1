﻿using ProjectDemo.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.Entity;

namespace ProjectDemo.Views
{
    /// <summary>
    /// Логика взаимодействия для CleaningView.xaml
    /// </summary>
    public partial class CleaningView : Page
    {
        public CleaningView()
        {
            InitializeComponent();
            LoadCleanings();
        }

        private void LoadCleanings()
        {
            using (var context = new DatabaseContext())
            {
                CleaningDataGrid.ItemsSource = context.RoomCleanings
                    .Include(c => c.Rooms)
                    .ToList();
            }
        }

        private void AddCleaning_Click(object sender, RoutedEventArgs e)
        {
            var window = new AddCleaningWindow();
            if (window.ShowDialog() == true)
            {
                LoadCleanings();
            }
        }

        private void UpdateStatus_Click(object sender, RoutedEventArgs e)
        {
            var selected = CleaningDataGrid.SelectedItem as RoomCleaning;
            if (selected != null)
            {
                var window = new UpdateCleaningStatusWindow(selected);
                if (window.ShowDialog() == true)
                {
                    LoadCleanings();
                }
            }
            else
            {
                MessageBox.Show("Выберите уборку для изменения статуса");
            }
        }
    }
}
