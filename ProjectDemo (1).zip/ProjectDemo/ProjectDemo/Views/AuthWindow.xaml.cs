﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ProjectDemo.Models;

namespace ProjectDemo.Views
{
    /// <summary>
    /// Логика взаимодействия для AuthWindow.xaml
    /// </summary>
    public partial class AuthWindow : Window
    {
        private int loginAttempts = 0;

        public AuthWindow()
        {
            InitializeComponent();
        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            string login = LoginTextBox.Text.Trim();
            string password = PasswordBox.Password.Trim();

            if (string.IsNullOrEmpty(login) || string.IsNullOrEmpty(password))
            {
                ErrorTextBlock.Text = "Логин и пароль обязательны для заполнения";
                return;
            }

            using (var context = new DatabaseContext())
            {
                var user = context.Users.FirstOrDefault(u => u.UserName == login);

                if (user == null || user.Password != password)
                {
                    loginAttempts++;
                    ErrorTextBlock.Text = "Вы ввели неверный логин или пароль. Пожалуйста проверьте ещё раз введенные данные";

                    if (loginAttempts >= 3)
                    {
                        user.Blocked = true;
                        context.SaveChanges();
                        ErrorTextBlock.Text = "Вы заблокированы. Обратитесь к администратору";
                        return;
                    }
                    return;
                }


                // Проверка на первый вход и необходимость смены пароля
                if (user.PasswordChanged == false)
                {
                    var changePasswordWindow = new ChangePasswordWindow(user.UserID);
                    changePasswordWindow.ShowDialog();

                    if (changePasswordWindow.DialogResult == true)
                    {
                        MessageBox.Show("Пароль успешно изменен. Пожалуйста, войдите снова.");
                        return;
                    }
                    else
                    {
                        return;
                    }
                }

                // Обновление даты последнего входа
                user.LastLoginDate = DateTime.Now;
                context.SaveChanges();

                MessageBox.Show("Вы успешно авторизовались");

                // Открытие соответствующей панели в зависимости от роли
                if (user.Roles.RoleName == "Admin")
                {
                    App.CurrentUser = user; // Сохраняем текущего пользователя
                    var adminDashboard = new AdminDashboard();
                    adminDashboard.Show();
                }
                else
                {
                    App.CurrentUser = user; // Сохраняем текущего пользователя
                    var userDashboard = new UserDashboard();
                    userDashboard.Show();
                }

                this.Close();
            }
        }
    }
}
