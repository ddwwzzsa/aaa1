﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.Entity;
using ProjectDemo.Models;

namespace ProjectDemo.Views
{
    /// <summary>
    /// Логика взаимодействия для AddServiceToOrderWindow.xaml
    /// </summary>
    public partial class AddServiceToOrderWindow : Window
    {
        private readonly int _orderId;

        public AddServiceToOrderWindow(int orderId)
        {
            InitializeComponent();
            _orderId = orderId;
            LoadServices();
        }

        private void LoadServices()
        {
            using (var context = new DatabaseContext())
            {
                ServiceComboBox.ItemsSource = context.HotelServices.ToList();
            }
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            if (ServiceComboBox.SelectedItem == null ||
                !int.TryParse(QuantityTextBox.Text, out int quantity) ||
                quantity <= 0)
            {
                MessageBox.Show("Заполните все поля корректно");
                return;
            }

            var orderedService = new OrderedServices
            {
                OrderID = _orderId,
                ServiceID = ((HotelServices)ServiceComboBox.SelectedItem).ServiceID,
                Quantity = quantity,
                OrderDate = DateTime.Now
            };

            using (var context = new DatabaseContext())
            {
                context.OrderedServices.Add(orderedService);
                context.SaveChanges();
            }

            DialogResult = true;
            Close();
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}
