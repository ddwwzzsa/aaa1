﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.Entity;
using ProjectDemo.Models;

namespace ProjectDemo.Views
{
    /// <summary>
    /// Логика взаимодействия для AddOrderWindow.xaml
    /// </summary>
    public partial class AddOrderWindow : Window
    {
        public AddOrderWindow()
        {
            InitializeComponent();
            LoadClients();
            LoadRooms();
            CheckInDatePicker.SelectedDate = DateTime.Today;
            CheckOutDatePicker.SelectedDate = DateTime.Today.AddDays(1);
        }

        private void LoadClients()
        {
            using (var context = new DatabaseContext())
            {
                ClientComboBox.ItemsSource = context.Clients.ToList();
            }
        }

        private void LoadRooms()
        {
            using (var context = new DatabaseContext())
            {
                RoomComboBox.ItemsSource = context.Rooms
                    .Where(r => r.RoomStatus == "Свободен")
                    .ToList();
            }
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if (ClientComboBox.SelectedItem == null ||
                RoomComboBox.SelectedItem == null ||
                CheckInDatePicker.SelectedDate == null ||
                CheckOutDatePicker.SelectedDate == null)
            {
                MessageBox.Show("Заполните все поля");
                return;
            }

            var order = new Orders
            {
                ClientID = ((Clients)ClientComboBox.SelectedItem).ClientID,
                RoomID = ((Rooms)RoomComboBox.SelectedItem).RoomID,
                CheckIn = CheckInDatePicker.SelectedDate.Value,
                CheckOut = CheckOutDatePicker.SelectedDate.Value,
                CardID = 1, // Временное значение, нужно реализовать карты доступа
                UserID = 1   // Временное значение, нужно передавать ID текущего пользователя
            };

            using (var context = new DatabaseContext())
            {
                context.Orders.Add(order);

                // Обновляем статус номера
                var room = context.Rooms.Find(order.RoomID);
                room.RoomStatus = "Занят";

                context.SaveChanges();
            }

            DialogResult = true;
            Close();
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}
