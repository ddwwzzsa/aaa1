﻿using ProjectDemo.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.Entity;

namespace ProjectDemo.Views
{
    /// <summary>
    /// Логика взаимодействия для ServicesView.xaml
    /// </summary>
    public partial class ServicesView : Page
    {
        public ServicesView()
        {
            InitializeComponent();
            LoadServices();
            LoadOrderedServices();
        }

        private void LoadServices()
        {
            using (var context = new DatabaseContext())
            {
                ServicesDataGrid.ItemsSource = context.HotelServices.ToList();
            }
        }

        private void LoadOrderedServices()
        {
            using (var context = new DatabaseContext())
            {
                OrderedServicesDataGrid.ItemsSource = context.OrderedServices
                    .Include(o => o.Orders)
                    .Include(o => o.HotelServices)
                    .ToList();
            }
        }

        private void AddService_Click(object sender, RoutedEventArgs e)
        {
            var window = new AddServiceWindow();
            if (window.ShowDialog() == true)
            {
                LoadServices();
            }
        }

        private void EditService_Click(object sender, RoutedEventArgs e)
        {
            var selected = ServicesDataGrid.SelectedItem as HotelServices;
            if (selected != null)
            {
                var window = new EditServiceWindow(selected);
                if (window.ShowDialog() == true)
                {
                    LoadServices();
                }
            }
            else
            {
                MessageBox.Show("Выберите услугу для редактирования");
            }
        }
    }
}
