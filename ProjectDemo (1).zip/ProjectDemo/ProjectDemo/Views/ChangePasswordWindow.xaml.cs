﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ProjectDemo.Models;

namespace ProjectDemo.Views
{
    /// <summary>
    /// Логика взаимодействия для ChangePasswordWindow.xaml
    /// </summary>
    public partial class ChangePasswordWindow : Window
    {
        private int userId;

        public ChangePasswordWindow(int userId)
        {
            InitializeComponent();
            this.userId = userId;
        }

        private void ChangePasswordButton_Click(object sender, RoutedEventArgs e)
        {
            string currentPassword = CurrentPasswordBox.Password;
            string newPassword = NewPasswordBox.Password;
            string confirmPassword = ConfirmPasswordBox.Password;

            if (string.IsNullOrEmpty(currentPassword) || string.IsNullOrEmpty(newPassword) || string.IsNullOrEmpty(confirmPassword))
            {
                ErrorTextBlock.Text = "Все поля обязательны для заполнения";
                return;
            }

            if (newPassword != confirmPassword)
            {
                ErrorTextBlock.Text = "Новый пароль и подтверждение не совпадают";
                return;
            }

            using (var context = new DatabaseContext())
            {
                var user = context.Users.Find(userId);

                if (user.Password != currentPassword)
                {
                    ErrorTextBlock.Text = "Текущий пароль введен неверно";
                    return;
                }

                user.Password = newPassword;
                user.PasswordChanged = true;
                context.SaveChanges();

                MessageBox.Show("Пароль успешно изменен");
                this.DialogResult = true;
                this.Close();
            }
        }
    }
}
